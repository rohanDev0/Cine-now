import React from "react";

const TEST_VIDEO =
  "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4";

function wnpdplayer() {
  return (
    <div
      style={{
        width: "100%",
        aspectRatio: "16 / 9",
        background: "#000",
        overflow: "hidden",
      }}
    >
      <video
  controls
  autoPlay
  muted
  playsInline
        src={TEST_VIDEO}
        controls
        playsInline
        style={{
          width: "100%",
          height: "100%",
          display: "block",
          objectFit: "contain",
          background: "#184233",
        }}
      />
    </div>
  );
}

export default wnpdplayer;
